# idiot moodle like me

My caes9821 mysteriously disappeared in Moodle, I can only access from the sidebar, very inconvenient!!
This plugin allows you to quickly access the course interface by simply replacing the search button, which is not useful at all.

### I hope it can be changed into a more convenient plugin than "HKU Moodle helper" in the future. Will someone help me write it :)